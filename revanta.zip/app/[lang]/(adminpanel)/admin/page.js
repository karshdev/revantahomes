"use client"
import AdminNavbar from "../../../../components/AdminNavbar";


const AdminDashboard = () => {
  

  return (
    <>
    <AdminNavbar />
    AdminDashboard
    </>
   
   
  );
};

export default AdminDashboard;

