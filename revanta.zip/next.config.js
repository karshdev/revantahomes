/** @type {import('next').NextConfig} */
const nextConfig = {
    // images:['https://media4.giphy.com/']
}

module.exports = nextConfig
